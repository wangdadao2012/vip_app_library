﻿//本地存储
var StorageEx = {
    support_localstorage_api: function () {
        try { return !(typeof window.localStorage == 'undefined'); } catch (e) { return false }
    },
    support_sessionstorage_api: function () {
        try { return !(typeof window.sessionStorage  == 'undefined'); } catch (e) { return false }
    },
    //============返回页面>>>>>>>>>>>
    keyBackReferrer: "backReferrer", 
    setBackReferrer: function () {
        StorageEx.set(StorageEx.keyBackReferrer, window.location.href);
    },
    getBackReferrer: function () {
        return StorageEx.get(StorageEx.keyBackReferrer);
    },


    get: function (key) {
        if (!StorageEx.support_localstorage_api()) return null;
        console.log("=======================localStorage=======================");
        console.log(localStorage);
        return localStorage[key];
    },
    set: function (key, obj) {
        if (!StorageEx.support_localstorage_api()) return;
        if (typeof (obj) != "string") {
            try {
                obj = obj.toJSONString();
            } catch (e) {
                console.log(obj);
            }
        }
        localStorage[key] = obj;
    },



    
    //============临时数据>>>>>>>>>>>
    getTemp: function (key) {
        if (!StorageEx.support_sessionstorage_api()) return null;
        console.log("=======================sessionStorage=======================");
        console.log(sessionStorage);
        return sessionStorage[key];
    },
    setTemp: function (key, obj) {
        if (!StorageEx.support_sessionstorage_api()) return;
        if (typeof (obj) != "string") {
            try {
                obj = obj.toJSONString();
            } catch (e) {
                console.log(obj);
            }
        }
        sessionStorage[key] = obj;
    },
    removeTemp: function (key) {
        console.log("removeTemp====="+key);
        if (!StorageEx.support_sessionstorage_api()) return null;        
        return sessionStorage.removeItem(key);
    },
}