

//DsBridge 入口：dsBridge
var bridge = {
    default: this, call: function (b, a, c) {
        var e = ""; "function" == typeof a && (c = a, a = {}); a = { data: void 0 === a ? null : a }; if ("function" == typeof c) { var g = "dscb" + window.dscb++; window[g] = c; a._dscbstub = g } a = JSON.stringify(a); if (window._dsbridge) e = _dsbridge.call(b, a); else if (window._dswk || -1 != navigator.userAgent.indexOf("_dsbridge")) e = prompt("_dsbridge=" + b, a); return JSON.parse(e || "{}").data
    },
    register: function (b, a, c) { c = c ? window._dsaf : window._dsf; window._dsInit || (window._dsInit = !0, setTimeout(function () { bridge.call("_dsb.dsinit") }, 0)); "object" == typeof a ? c._obs[b] = a : c[b] = a },
    registerAsyn: function (b, a) { this.register(b, a, !0) },
    hasNativeMethod: function (b, a) { return this.call("_dsb.hasNativeMethod", { name: b, type: a || "all" }) },
    disableJavascriptDialogBlock: function (b) { this.call("_dsb.disableJavascriptDialogBlock", { disable: !1 !== b }) }
};
!function () {
    if (!window._dsf) {
        var b = {
            _dsf: { _obs: {} }, _dsaf: { _obs: {} }, dscb: 0,
            dsBridge: bridge,
            close: function () { bridge.call("_dsb.closePage") },
            _handleMessageFromNative: function (a) {
                var e = JSON.parse(a.data), b = { id: a.callbackId, complete: !0 }, c = this._dsf[a.method], d = this._dsaf[a.method], h = function (a, c) { b.data = a.apply(c, e); bridge.call("_dsb.returnValue", b) }, k = function (a, c) { e.push(function (a, c) { b.data = a; b.complete = !1 !== c; bridge.call("_dsb.returnValue", b) }); a.apply(c, e) }; if (c) h(c, this._dsf); else if (d) k(d, this._dsaf);
                else if (c = a.method.split("."), !(2 > c.length)) { a = c.pop(); var c = c.join("."), d = this._dsf._obs, d = d[c] || {}, f = d[a]; f && "function" == typeof f ? h(f, d) : (d = this._dsaf._obs, d = d[c] || {}, (f = d[a]) && "function" == typeof f && k(f, d)) }
            }
        }, a; for (a in b) window[a] = b[a]; bridge.register("_hasJavascriptMethod", function (a, b) { b = a.split("."); if (2 > b.length) return !(!_dsf[b] && !_dsaf[b]); a = b.pop(); b = b.join("."); return (b = _dsf._obs[b] || _dsaf._obs[b]) && !!b[a] })
    }
}();
//module.exports = bridge;

//-------------------Console------------
function log(msg) {
    console.log(msg);
}
function logD(msg) {
    console.debug(msg);
}
function logE(msg) {
    console.error(msg);
}

//-------------------Console------------

var App = {
    Debug: false,    
	Domain: "http://wxmini.123580.com", 
	AppID: "wxef6a8fdc482cf6be",
	UserInfo:null,
	UserNo: "",
	JsBridge: dsBridge,
    init: function () {		
        log(">>>>>>>>>>>>>>>>>>>Base Info<<<<<<<<<<<<<<<<<<<");        
        log("Domain=" + this.Domain);
        log("AppID=" + this.AppID);
        log("UserInfo=" + this.UserInfo);
        log("UserNo=" + this.UserNo);
        log("<<<<<<<<<<<<<<<<<<<Base Info<<<<<<<<<<<<<<<<<<<");
    },//init 
	
		
	api: function (controller, method, param, success, error, complete) {
	    log("App.api " + controller + " " + method + " " + param + " " + success);
     

    },//api

	getApiURL: function (controller, method) {
	    return this.Domain + "/api/" + controller + ".ashx?method=" + method + "&t=" + new Date().getTime();
	},//getApiURL

	getUrl: function (vpath) {
	    if (vpath == null || vpath == "")
	        return "";

	    var index = vpath.indexOf('http');
	    if (index == 0) return vpath;

	    return this.Domain + vpath;
	},
    
    run: function (fun) {
        if (fun == null) return;
        try {
            fun();
        }
        catch (e) {
            console.error("------------------- CP.run -------------------");
            console.error(e);
        }

    },//run

    isSuccess: function (obj) {
        if (obj == null || typeof (obj) != "object") return false;
        return obj.Result == "success";
    },//isSuccess    



    //-------------------JsBridge-----------

    //关闭当前页面，跳转到应用内的某个页面。
    redirectTo: function (param, result) {
        this.callBridge("redirectTo", param, result);
    },//redirectTo
    //保留当前页面，跳转到应用内的某个页面，使用navigateBack可以返回到原页面
    navigateTo: function (param, result) {
        this.callBridge("navigateTo", param, result);
    },//navigateTo
    navigateBack: function (param, result) {
        this.callBridge("navigateBack", param, result);
    },//navigateBack    
    //跳转到 tabBar 页面，并关闭其他所有非 tabBar 页面
    switchTab: function (param, result) {
        this.callBridge("switchTab", param, result);
    },//switchTab
    //关闭所有页面,重启App
    reLaunch: function (param, result) {
        this.callBridge("reLaunch", param, result);
    },//reLaunch


    getSystemInfo: function (result) {
        this.callBridge("getSystemInfo", null, result);
    },//getSystemInfo
    getNetworkType: function (result) {
        this.callBridge("getNetworkType", null, result);
    },//getNetworkType

    makePhoneCall: function (tel) {
        this.callBridge("makePhoneCall", tel);
    },//makePhoneCall

    getLocation: function (result) {
        this.callBridge("getLocation", null, result);
    },//getLocation
    scanCode: function (result) {
        this.callBridge("scanCode", null, result);
    },//scanCode

    showLoading: function (param, complete) {
        this.callBridge("showLoading", param, null, null, complete);
    },//showLoading
    hideLoading: function (param, complete) {
        this.callBridge("hideLoading", param, null, null, complete);
    },//hideLoading

    
    showToast: function (param, complete) {
        this.callBridge("showToast", param, null, null, complete);
    },//showToast
    hideToast: function (param, complete) {
        this.callBridge("hideToast", param, null, null, complete);
    },//hideToast

    showActionSheet: function (param, complete) {
        this.callBridge("showActionSheet", param, null, null, complete);
    },//hideLoading

    callBridge: function (method, param, success, fail, complete) {
        this.Bridge.call(method, param, function (data) {
            if (success != null)
                success(data);

            if (fail != null)
                fail(data);            

            if (complete != null)
                complete();
        });
    },//callBridge

    //-------------------JsBridge-----------

}//App


var Util = {

    //基于axios
    get: function (url, param, success, error, complete) {
        axios.get(url, param)
        .then(function (response) {
            if (success != null)
                success(response);

            if (complete != null)
                complete();
        })
        .catch(function (ex) {
            if (error != null)
                error(ex);

            if (complete != null)
                complete();
        });
    },//get	

    //基于axios
    post: function (url, param, confing, success, error, complete) {
        if (confing == null)
            confing = { headers: { 'Content-Type': 'application/json' } };

        axios.post(url, param, confing)
        .then(function (response) {
            if (success != null)
                success(response);

            if (complete != null)
                complete();
        })
        .catch(function (ex) {
            if (error != null)
                error(ex);

            if (complete != null)
                complete();
        });
    },//post

    run: function (fun) {
        if (fun == null) return;
        try {
            fun();
        }
        catch (e) {
            console.error("------------------- CP.run -------------------");
            console.error(e);
        }
    },//run

    getQueryString: function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]); return null;
    },//getQueryString

    clone: function (obj1, obj2) {
        if (obj2 == null) obj2 = {};
        return $.extend(true, obj2, obj1);
    },//clone

    random: function (n) {
        var chars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
        var res = "";
        for (var i = 0; i < n; i++) {
            var id = Math.ceil(Math.random() * chars.length - 1);
            res += chars[id];
        }
        return res;
    },//random

    toJSON: function (obj) {
        return JSON.stringify(obj);
    },//toJSON

    evalJSON: function (obj) {
        return JSON.parse(json);
    },//evelJSON

    isEmpty: function (txt) {
        return $.trim(txt) == "";
    },//isEmpty

    inFrame: function () {
        return (top.location != location);
    },//inFrame



    //=======格式化===========
    formatUtil: {

        fmtShortDateTime: function (value) {
            try {
                var fmt = "yyyy-MM-dd hh:mm:ss";
                if (typeof (value) == 'object') {
                    return CP.fmtDate2Str(value, fmt);
                }
                else {
                    if (value.indexOf("T") > 0) {
                        var index = value.lastIndexOf(".");
                        value = value.replace("T", " ");
                        if (index >= 0)
                            value = value.slice(0, index);
                        return value;
                    }

                    if (CP.indexOf(value, "Date(") >= 0) {
                        value = value.substring(CP.indexOf(value, "(") + 1, CP.indexOf(value, ")"));
                        return CP.fmtDate2Str(new Date(parseFloat(value)), fmt);
                    }
                }
            } catch (e) {
                //console.log(e);
                return "";
            }

            return value;
        },//fmtShortDateTime
        fmtShortDate: function (value) {
            try {
                if (typeof (value) == 'object') {
                    return CP.fmtDate2Str(value, "yyyy-MM-dd");
                }
                else {
                    if (value.indexOf("T") > 0)
                        return value.slice(0, value.lastIndexOf("T"))

                    else if (value.indexOf(" ") > 0)
                        return value.slice(0, value.lastIndexOf(" "))
                    else if (!isNaN(value) && value.length == 8)
                        return value.substr(0, 4) + "-" + value.substr(4, 2) + "-" + value.substr(6, 2)
                    else
                        return value.slice(0, 10);
                }
            } catch (e) {
                //console.log(e);
                return "";
            }
            return value;
        },//fmtShortDate
        fmtDate2Str: function (dateObj, fmt) {
            var o = {
                "M+": dateObj.getMonth() + 1, //月份     
                "d+": dateObj.getDate(), //日     
                "h+": dateObj.getHours() % 12 == 0 ? 12 : dateObj.getHours() % 12, //小时     
                "H+": dateObj.getHours(), //小时     
                "m+": dateObj.getMinutes(), //分     
                "s+": dateObj.getSeconds(), //秒     
                "q+": Math.floor((dateObj.getMonth() + 3) / 3), //季度     
                "S": dateObj.getMilliseconds() //毫秒     
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (dateObj.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[dateObj.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        },//fmtDate2Str
        fmtStr2Date: function (str) {
            try {
                str = CP.fmtShortDateTime(str);
                var arr1 = str.split(" ");
                var arrDate = arr1[0].split("-");
                var arrTime = arr1[1].split(":");
                return new Date(arrDate[0], parseInt(arrDate[1]) - 1, arrDate[2], arrTime[0], arrTime[1], arrTime[2])
            } catch (e) {
                console.error(e);
                return new Date();
            }
        },//fmtStr2Date
    },//formatUtil


    //=======Timer 时间===========
    TimerUtil: {
        //倒计时器
        createCountDown: function (callback, sec) {
            if (sec == null)
                sec = 60;

            var obj = {
                val: sec,
                callback: callback,
                active: true,
                run: function () {
                    setTimeout(function () {
                        obj.val--;
                        if (callback != null)
                            callback(obj.val, (obj.val == 0));

                        if (!obj.active)
                            return;

                        if (obj.val > 0)
                            obj.run();
                    }, 1000);
                },//run
                stop: function () {
                    obj.active = true;
                },//stop
            }

            obj.run();
            return obj;
        },
        clear: function (timer) {
            if (timer == null) return;
            clearTimeout(timer);
            clearInterval(timer);
        },//clear
    },//TimerUtil


    //=======Scroll滚动===========
    ScrollUtil: {
        toTop: function (top, speed, delay, target) {
            try {

                if (top == null) return;

                if (target == null)
                    target = $('body,html');

                if (speed == null)
                    speed = 0;

                if (delay == null)
                    delay = 0;

                setTimeout(function () {
                    target.animate({ scrollTop: top }, speed);
                }, delay);

            } catch (e) {
                console.log(e);
            }
        },//toTop
    },//ScrollUtil


    //-------------------Array-----------
    ArrayUtil: {
        remove: function (arr, item) {
            try {
                $.each(arr, function (index, item2) {
                    if (item2 == item) {
                        arr.splice(index, 1);
                    }
                });

            } catch (e) {
                console.log(e);
            }
        },//remove
        removeIndex: function (arr, index) {
            try {
                arr.splice(index, 1);
            } catch (e) {
                console.log(e);
            }
        },//remove        
    },//ArrayUtil

    //-------------------Array-----------

    //-------------------Window-----------
    alert: function (msg, title, callback) {

    },//alert
    confirm: function (msg, op1, op2, op3) {

    },//confirm
    toast: function (message, op) {

    },//toast

    //-------------------Window-----------
      
    
}//Util



var Storage = {
    
    support_localstorage_api: function () {
        try { return !(typeof window.localStorage == 'undefined'); } catch (e) { return false }
    },
    support_sessionstorage_api: function () {
        try { return !(typeof window.sessionStorage == 'undefined'); } catch (e) { return false }
    },

    get: function (key) {
        if (!this.support_localstorage_api()) return null;
        return localStorage[key] || "";
    },
    set: function (key, val) {
        if (!this.support_localstorage_api()) return;
        
        if (val == null)
            val = "";

        if (typeof (val) != "string") {
            try {
                obj = JSON.stringify(val);
            } catch (e) {
            }
        }
        
        localStorage[key] = val;
        return val;
    },

    getTemp: function (key) {
        if (!this.support_sessionstorage_api()) return null;
        return sessionStorage[key];
    },
    setTemp: function (key, obj) {
        if (!this.support_sessionstorage_api()) return;
        if (typeof (obj) != "string") {
            try {
                obj = obj.toJSONString();
            } catch (e) {
                console.log(obj);
            }
        }
        sessionStorage[key] = obj;
    },
    removeTemp: function (key) {
        console.log("removeTemp=====" + key);
        if (!StorageEx.support_sessionstorage_api()) return null;
        return sessionStorage.removeItem(key);
    },


    clear: function () {
        localStorage.clear();
    },

    isEmpty: function (val) {
        return (val == null || val == "");
    }
}


var Page = {
    Page: "",
    Controller:"",
    Param: null,
    Data:null,
    Instance: null,
    Api:null,
    init: function (param) {
        App.init();

        if (this.Instance != null) return;
       
        this.Page = param.Page;
        this.Controller = param.Controller
        this.Api = param.Api;
        this.Data = param.data;

        this.Param = {
            el: '#page',
            data: param.data,
            methods: param.methods,
            created: param.created,//创建开始
            beforeCompile: param.beforeCompile,////编译之前
            compiled: param.compiled,//编译结束后,但是不担保 $el 已插入文档
            ready: param.ready,//编译结束,一切准备好了
            attached: param.attached,//插入DOM成功
            detached: param.detached,//删除DOM成功
            beforeDestroy: param.beforeDestroy,//销毁前
            destroyed: param.destroyed,//已销毁
            computed: {
                now: function () {
                    return Date.now()
                }
            }
        }

        this.Instance = new Vue(this.Param);

        return this;
    },
    setData: function (param) {
        if (param == null) return;

        for (var key in param) {
            this.Param.data[key] = param[key];
        }
        this.Data = this.Param.data;
    },//setData    
}


