var App = {
    Debug: false,    
    ApiUrl: null,
    AppUrl: null,
    HtmlUrl: null,    
	Domain: "https://wxmini.123580.com", 
	AppID: "wxef6a8fdc482cf6be",
	UserInfo:null,
	UserNo: "",
	
	
    init: function () {		
        console.log(">>>>>>>>>>>>>>>>>>>Base Info<<<<<<<<<<<<<<<<<<<");        
        console.log("ApiUrl=" + this.ApiUrl);
        console.log("AppUrl=" + this.AppUrl);
        console.log("<<<<<<<<<<<<<<<<<<<Base Info<<<<<<<<<<<<<<<<<<<");
    },//init 
	
	get:function(key){},
	set:function(key,val){},
		
    post: function (p1, p2, p3, p4) {
        log("CP.api " + p1 + " " + p2 + " " + p3 + " " + p4);
        var op = {
            method: "",
            param: null,
            callback: null,
            success: null,
            error: null,
            complete: null,
            showLoading: false,
        };

        var options = null;
        if (typeof (p1) == "object") {
            options = p1;
        }
        else {
            op.method = p1;
            if (typeof (p2) == "function") {
                op.callback = p2;
                options = p3;
            }
            else {
                op.param = p2;
                op.callback = p3;
                options = p4;
                log("p4");
                log(p4);
            }
        }

        log(options);
        if (options != null)
            op = CP.clone(options, op);

        log(op);

        var url = CP.getApiURL(op.method);

        log("url=" + url);

        if (op.param != null) {
            for (var i in op.param) {
                var val = op.param[i];
                if (val != null && typeof (val) == "object") {
                    op.param[i] = CP.toJSON(val);
                }
            }
        }

        var loading = null;
        if (op.showLoading)
            loading = CP.showLoading(30 * 1000);

        $.post(url, op.param, function (result) {
            CP.logF(op.act);

            CP.testStart("url==>" + url);
            CP.logD(result);
            var data = CP.evalJSON(result);
            CP.logD(data);
            CP.testEnd();

            if (op.callback != null) {
                op.callback(result, data);
            }
        })
        .success(function () {
            if (op.success != null)
                op.success();
        })
        .error(function () {
            if (op.error != null)
                op.error();
        })
        .complete(function () {
            if (op.complete != null)
                op.complete();

            if (loading != null)
                CP.hideLoading(loading);
        })

    },//api

    getApiURL: function (method) {
        return CP.ApiUrl + "/" + method + "/" + new Date().getTime();
    },//getApiURL

    getHtmlURL: function (type,id) {
        return CP.HtmlUrl + "/" + type + "/" + id + "?r=" + new Date().getTime();
    },//getApiURL

    getFullURL: function (path) {
        if (path == null) return;
        var reg = new RegExp("^../");
        var flag = reg.test(path);

        path = path.replace("../", "/").replace("~/", "/");
        if (path[0] != '/')
            path = "/" + path;

        if (flag)
            return CP.AppUrl + path;
        else
            return CP.BaseUrl + path;
    },//getApiURL

    run: function (fun) {
        if (fun == null) return;
        try {
            fun();
        }
        catch (e) {
            console.error("------------------- CP.run -------------------");
            console.error(e);
        }

    },//run

    showLoading: function (time) {
        var htmMask = '<div class="loadingMask" style="display:block;position: fixed;left: 0px;right: 0px;top: 0px;bottom:0px;height: auto;width:auto;background-color:rgba(255, 255, 255, 0.5);z-index:10000000;"></div>';
        var htmLoading = '<div class="loadingDiv mui-spinner" style="display:block;width: 80px;height: 80px;position:fixed;top: 50%;left: 50%;border: 0;z-index: 10000001;margin-left:-40px; margin-top:-40px; opacity: 0.98;color: red"></div>';

        if ($(".loadingDiv").length == 0)
            $("body").append(htmLoading);

        if ($(".loadingMask").length == 0)
            $("body").append(htmMask);

        var mask = $(".loadingMask");
        var loading = $(".loadingDiv");
        mask.show();
        loading.show();
        if (time != null && time > 0) {
            var timer = setTimeout(function () { CP.hideLoading(timer); }, time);
            return timer;
        }
        return null;
    },//showLoading

    hideLoading: function (timer) {
        if (timer != null)
            clearTimeout(timer);

        setTimeout(function () {
            $(".loadingMask").hide().remove();
            $(".loadingDiv").hide().remove();
        }, 500);
    },//hideLoading

    getQueryString: function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]); return null;
    },//getQueryString

    clone: function (obj1, obj2) {
        if (obj2 == null) obj2 = {};
        return $.extend(true, obj2, obj1);
    },//clone

    random: function (n) {
        var chars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
        var res = "";
        for (var i = 0; i < n; i++) {
            var id = Math.ceil(Math.random() * chars.length - 1);
            res += chars[id];
        }
        return res;
    },//random

    toJSON: function (obj) { return $.toJSON(obj); },//toJSON

    evalJSON: function (obj) {
        try {
            obj = obj.replace("\\\\", "＼").replace("\\", "＼");
            return $.evalJSON(obj);
        } catch (e) { console.log(e) }
    },//evelJSON

    isSuccess: function (obj) {
        console.log(obj);
        if (obj == null || typeof (obj) != "object") return false;

        return obj.Result == "success";
    },//isSuccess

    enterFocus: function (selector, callback) {
        /*例子：
        CP.enterfocus('#login-form input', function () {            
            $.trigger(loginButton, 'click');
        });
        */
        var boxArray = [].slice.call(document.querySelectorAll(selector));
        for (var index in boxArray) {
            var box = boxArray[index];
            box.addEventListener('keyup', function (event) {
                if (event.keyCode == 13) {
                    var boxIndex = boxArray.indexOf(this);
                    if (boxIndex == boxArray.length - 1) {
                        if (callback) callback();
                    } else {
                        var nextBox = boxArray[++boxIndex];
                        nextBox.focus();
                    }
                }
            }, false);
        }
    },//enterfocus

    isEmpty: function (txt) {
        return $.trim(txt) == "";
    },//isEmpty

    inFrame: function () {
        return (top.location != location);
    },//inFrame

    fmtShortDateTime: function (value) {
        try {
            var fmt = "yyyy-MM-dd hh:mm:ss";
            if (typeof (value) == 'object') {
                return CP.fmtDate2Str(value, fmt);
            }
            else {
                if (value.indexOf("T") > 0) {
                    var index = value.lastIndexOf(".");
                    value = value.replace("T", " ");
                    if (index >= 0)
                        value = value.slice(0, index);
                    return value;
                }

                if (CP.indexOf(value, "Date(") >= 0) {
                    value = value.substring(CP.indexOf(value, "(") + 1, CP.indexOf(value, ")"));
                    return CP.fmtDate2Str(new Date(parseFloat(value)), fmt);
                }
            }
        } catch (e) {
            //console.log(e);
            return "";
        }

        return value;
    },//fmtShortDateTime
    fmtShortDate: function (value) {
        try {
            if (typeof (value) == 'object') {
                return CP.fmtDate2Str(value, "yyyy-MM-dd");
            }
            else {
                if (value.indexOf("T") > 0)
                    return value.slice(0, value.lastIndexOf("T"))

                else if (value.indexOf(" ") > 0)
                    return value.slice(0, value.lastIndexOf(" "))
                else if (!isNaN(value) && value.length == 8)
                    return value.substr(0, 4) + "-" + value.substr(4, 2) + "-" + value.substr(6, 2)
                else
                    return value.slice(0, 10);
            }
        } catch (e) {
            //console.log(e);
            return "";
        }
        return value;
    },//fmtShortDate

    fmtDate2Str: function (dateObj, fmt) {
        var o = {
            "M+": dateObj.getMonth() + 1, //月份     
            "d+": dateObj.getDate(), //日     
            "h+": dateObj.getHours() % 12 == 0 ? 12 : dateObj.getHours() % 12, //小时     
            "H+": dateObj.getHours(), //小时     
            "m+": dateObj.getMinutes(), //分     
            "s+": dateObj.getSeconds(), //秒     
            "q+": Math.floor((dateObj.getMonth() + 3) / 3), //季度     
            "S": dateObj.getMilliseconds() //毫秒     
        };
        var week = {
            "0": "\u65e5",
            "1": "\u4e00",
            "2": "\u4e8c",
            "3": "\u4e09",
            "4": "\u56db",
            "5": "\u4e94",
            "6": "\u516d"
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (dateObj.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        if (/(E+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[dateObj.getDay() + ""]);
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    },//fmtDate2Str
    fmtStr2Date: function (str) {
        try {
            str = CP.fmtShortDateTime(str);
            var arr1 = str.split(" ");
            var arrDate = arr1[0].split("-");
            var arrTime = arr1[1].split(":");
            return new Date(arrDate[0], parseInt(arrDate[1]) - 1, arrDate[2], arrTime[0], arrTime[1], arrTime[2])
        } catch (e) {
            console.error(e);
            return new Date();
        }
    },//fmtStr2Date

    //=======Timer 时间===========
	TimerUtil:{
		//倒计时器
		createCountDown : function (callback, sec) {
			if (sec == null)
				sec = 60;

			var obj = {        
				val: sec,
				callback: callback,
				active:true,
				run: function () {            
					setTimeout(function () {					
						obj.val--;
						if (callback!=null)
							callback(obj.val, (obj.val == 0));
						
						if(!obj.active)
							return;

						if (obj.val > 0) 
							obj.run();
					}, 1000);
				},//run
				stop:function(){
					obj.active=true;										
				},//stop
			}		

			obj.run();
			return obj;
		},
		clear:function(timer){
			if(timer==null) return;
			clearTimeout(timer);
			clearInterval(timer);
		},//clear
	},//TimerUtil
    

    //=======Scroll滚动===========
	ScrollUtil:{
		toTop: function (top, speed, delay, target) {
			try {

				if (top == null) return;

				if (target == null)
					target = $('body,html');

				if (speed == null)
					speed = 0;

				if (delay == null)
					delay = 0;

				setTimeout(function () {
					target.animate({ scrollTop: top }, speed);
				}, delay);

			} catch (e) {
				console.log(e);
			}
		},//toTop
	},//ScrollUtil
   

    //-------------------Array-----------
    ArrayUtil: {
        remove: function (arr, item) {
            try {
                $.each(arr, function (index, item2) {
                    if (item2 == item) {
                        arr.splice(index, 1);
                    }
                });

            } catch (e) {
                console.log(e);
            }
        },//remove
        removeIndex: function (arr, index) {
            try {
                arr.splice(index, 1);
            } catch (e) {
                console.log(e);
            }
        },//remove        
    },//ArrayUtil

    //-------------------Array-----------

    //-------------------Window-----------
    alert: function (msg, title, callback) {
        
    },//alert
    confirm: function (msg, op1, op2, op3) {
        
    },//confirm
    toast: function (message, op) {
        
    },//toast

    //-------------------Window-----------
    

    //-------------------Console------------
    log: function (msg) {
        console.log(msg);
    },
    logD: function (msg) {
        console.debug(msg);
    },
    logE: function (msg) {
        console.error(msg);
    },

    //-------------------Console------------
}

$(function () {
    App.init();
})