﻿/* Debug/index.js */

var vm = Page.init({
    Page: "Debug",
    Controller:"",
    data: {
        showDialog: false,
        message: "Test",
    },//data
    methods: {
        jump: function (page) {
            log(page);
            App.navigateTo({ Page:page });
        },//jump

        getSystemInfo: function () {
            App.getSystemInfo(function (value) {
                vm.setData({ message: value });
                vm.toggleDialog();
            });
        },//getSystemInfo

        toggleDialog: function () {
            vm.setData({ showDialog:!(vm.Data.showDialog) });
        },//toggleDialog

    },//methods
})

vm.toggleDialog=function() {
    vm.setData({ showDialog: !(vm.Data.showDialog) });
}




