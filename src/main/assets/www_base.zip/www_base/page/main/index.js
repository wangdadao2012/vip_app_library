﻿/* Main/index.js */

var $ = Page.init({
    Page: "Main",
    Controller: "",
    data: {
       
    },//data
    methods: {
       
    },//methods
})

