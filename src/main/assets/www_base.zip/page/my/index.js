﻿/* My/index.js */

var $ = Page.init({
    Page: "My",
    data: {
       
    },//data
    methods: {
       
    },//methods
})

