$(function(){
	$("#id1").html("加载jquery成功");
	$("#id2").html("程序更新成功.v1.0.2");
})