﻿/* Login/index.js */

var $ = Page.init({
    Page: "Login",
    Controller: "",
    data: {
        userNo:"",
        welcome: "",
    },//data
    methods: {
        login: function () {
            $.setData({ userNo: "aaaaaaaaaaaaaaaaaa" });
        },//login
        say: function (mg) {
            log(mg);
            $.setData({ welcome: mg });
        },//say
    },//methods
    Api: {

    },//Api
})

